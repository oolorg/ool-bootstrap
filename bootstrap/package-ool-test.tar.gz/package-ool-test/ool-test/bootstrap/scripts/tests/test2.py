#!/usr/bin/env python
# -*- coding: utf-8 -*-

def test():
	print "bb"

#test("aa")

moji="test"

eval('moji()')
